<!-- add a toggle -->

# Progress

## 12/25/2022
v0.0.1
- [*] Basic Code
- [*] Basic UI
- [*] Basic Generator


## 12/25/2022
v0.0.2

- [*] Added a Undo Button
- [*] Added a New Summarizer with Hugging Face 
- [*] Changed the UI
- [*] Added Stack to Store Previous History
- [*] Minor Bug Fixes and Code Refactoring 
