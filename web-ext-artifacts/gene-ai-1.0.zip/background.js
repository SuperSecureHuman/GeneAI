/*
TODO: Summarizers,ParaPhaser
*/

browser.contextMenus.create({
  id: "Generate",
  title: "Generate Text",
  contexts: ["all"],
});

// "https://api-inference.huggingface.co/models/gpt2",
// "https://api-inference.huggingface.co/models/EleutherAI/gpt-j-6B",

async function Generator(data) {
  const response = await fetch(
    "https://api-inference.huggingface.co/models/bigscience/bloom",
    {
      headers: {
        Authorization: "Bearer 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",
      },
      method: "POST",
      body: JSON.stringify(data),
    
    }
  );
  const result = await response.json();
  return result;
}

async function Summarizer(data) {
  const response = await fetch(
    "https://api-inference.huggingface.co/models/facebook/bart-large-cnn",
    {
      headers: {
        Authorization: "Bearer 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",
      },
      method: "POST",
      body: JSON.stringify(data),
    
    }
  );
  const result = await response.json();
  return result;
}

async function SummarizerV2(paragraph,number){
  const response=await fetch(
    "https://www.everyprompt.com/api/v0/calls/gene-ai/summary--hJk-c",
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: "Bearer jOjKAhl6_idAGYiie900L",
      },
      body: JSON.stringify({
        "variables": {
          "paragraph": `${paragraph}`,
          "number": `${number}`,
        },
        "user": "testing"
      }),
    }
  );
  const result=await response.json();
  console.log(result);
  return result;
}

browser.contextMenus.onClicked.addListener(function (info, tab) {
  if (info.menuItemId == "Generate") {
    console.log("Input");
    console.log(info.selectionText);
    Generator({ inputs: info.selectionText }).then((response) => {
      console.log("Generated From Background.js");
      console.log(response[0].generated_text);
    });
  }
});

browser.runtime.onMessage.addListener((request, sender, sendResponse) => {
  let text = request.text;
  let dropdown = request.dropdown;
  let key_number=   request.number;
  if (dropdown == "generate"){

    Generator({ inputs: text }).then((response) => {
      let result = response[0].generated_text;
      sendResponse({ result: result });
      console.log(response[0].generated_text);
    });
  }
  else if (dropdown == "Summarizer"){
    Summarizer({ inputs: text }).then((response) => {
      let result = response[0].summary_text;
      sendResponse({ result: result });
      console.log(response[0].summary_text);
    });
  }
  else if (dropdown == "SummarizerV2"){
    console.log("Summarizer V2");
    SummarizerV2(text,key_number).then((response) => {
      let result = response;
      sendResponse({ result: result.choices[0].text });
      console.log(result);
    });

  }
  return true;
});
